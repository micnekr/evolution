def A():
  print("A")
def B():
  print("B")
def C ():
  print("C")
def D():
  print("D")
def E():
  print("E")
def F():
  print("F")
def G():
  print("G")
def H():
  print("H")
def I():
  print("I")
def J():
  print("J")
def K():
  print("K")
def L():
  print("L")
def M():
  print("M")
def N():
  print("N")
def O():
  print("O")
def P():
  print("P")
def Q():
  print("Q")
def R():
  print("R")
def S():
  print("S")
def T():
  print("T")
def U():
  print("U")
def V():
  print("V")
def W():
  print("W")
def X():
  print("X")
def Y():
  print("Y")  
def Z():
  print("Z")